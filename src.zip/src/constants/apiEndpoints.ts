export const API_ENDPOINTS = {
  BASE_URL: 'http://localhost:5000/api',
  REFRESH_TOKEN: '/auth/refresh-token',
  LOGIN: '/auth/login',
  USER_ME: '/user/me',
};

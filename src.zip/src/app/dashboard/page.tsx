
"use client";
import React, { useEffect, useState } from "react";
import { apiService } from "@/services/apiService";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";

interface Book {
  _id: string;
  title: string;
  author: string;
  summary: string;
  publisher: string;
  price: number;
  rating: number;
  quantity: number;
  sold: number;
  isDisable: boolean;
  createdAt: string;
  updatedAt: string;
}
interface Category {
  _id: string;
  name: string;
  description: string;
  isDisable: boolean;
  createdAt: string;
  updatedAt: string;
}
interface User {
  _id: string;
  username: string;
  fullname: string;
  email: string;
  phone: string;
  gender: string;
  birthday: string;
  avatar: string;
  persona: string;
  address: string;
  createdAt: string;
  updatedAt: string;
  isDisable?: boolean;
}

const tabs = [
  { key: "books", label: "Books" },
  { key: "categories", label: "Categories" },
  { key: "users", label: "Users" },
];

export default function DashboardPage() {
  const [books, setBooks] = useState<Book[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [tab, setTab] = useState("books");

  useEffect(() => {
    apiService.get("/book").then((res) => setBooks(res.data));
    apiService.get("/category").then((res) => setCategories(res.data));
    apiService.get("/user").then((res) => setUsers(res.data));
  }, []);

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-4xl font-bold mb-8 text-gray-800">Admin Dashboard</h1>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
          <Card>
            <CardHeader>
              <CardTitle>Total Books</CardTitle>
            </CardHeader>
            <CardContent className="text-2xl font-bold">{books.length}</CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Total Categories</CardTitle>
            </CardHeader>
            <CardContent className="text-2xl font-bold">{categories.length}</CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Total Users</CardTitle>
            </CardHeader>
            <CardContent className="text-2xl font-bold">{users.length}</CardContent>
          </Card>
        </div>

        <Tabs value={tab} onValueChange={setTab}>
          <TabsList>
            {tabs.map((t) => (
              <TabsTrigger key={t.key} value={t.key}>{t.label}</TabsTrigger>
            ))}
          </TabsList>

          <TabsContent value="books">
            <Card>
              <CardHeader>
                <CardTitle>Books</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="min-w-full text-sm text-left">
                  <thead className="bg-gray-100">
                    <tr>
                      <th className="px-4 py-2">Title</th>
                      <th className="px-4 py-2">Author</th>
                      <th className="px-4 py-2">Price</th>
                      <th className="px-4 py-2">Rating</th>
                      <th className="px-4 py-2">Quantity</th>
                      <th className="px-4 py-2">Sold</th>
                      <th className="px-4 py-2">Disable</th>
                    </tr>
                  </thead>
                  <tbody>
                    {books.map((b) => (
                      <tr key={b._id} className="border-b hover:bg-gray-50">
                        <td className="px-4 py-2 font-medium">{b.title}</td>
                        <td className="px-4 py-2">{b.author}</td>
                        <td className="px-4 py-2">{b.price.toLocaleString()}₫</td>
                        <td className="px-4 py-2">{b.rating}</td>
                        <td className="px-4 py-2">{b.quantity}</td>
                        <td className="px-4 py-2">{b.sold}</td>
                          <td className="px-4 py-2">
                            <Badge variant={b.isDisable ? "destructive" : "success"}>
                              {b.isDisable ? "Disabled" : "Active"}
                            </Badge>
                          </td>
                      </tr>
                    ))}
                  </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="categories">
            <Card>
              <CardHeader>
                <CardTitle>Categories</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="min-w-full text-sm text-left">
                  <thead className="bg-gray-100">
                    <tr>
                      <th className="px-4 py-2">Name</th>
                      <th className="px-4 py-2">Description</th>
                      <th className="px-4 py-2">Disable</th>
                    </tr>
                  </thead>
                  <tbody>
                    {categories.map((c) => (
                      <tr key={c._id} className="border-b hover:bg-gray-50">
                        <td className="px-4 py-2 font-medium">{c.name}</td>
                        <td className="px-4 py-2">{c.description}</td>
                          <td className="px-4 py-2">
                            <Badge variant={c.isDisable ? "destructive" : "success"}>
                              {c.isDisable ? "Disabled" : "Active"}
                            </Badge>
                          </td>
                      </tr>
                    ))}
                  </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="users">
            <Card>
              <CardHeader>
                <CardTitle>Users</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="min-w-full text-sm text-left">
                  <thead className="bg-gray-100">
                    <tr>
                      <th className="px-4 py-2">Avatar</th>
                      <th className="px-4 py-2">Username</th>
                      <th className="px-4 py-2">Fullname</th>
                      <th className="px-4 py-2">Email</th>
                      <th className="px-4 py-2">Phone</th>
                      <th className="px-4 py-2">Gender</th>
                      <th className="px-4 py-2">Birthday</th>
                      <th className="px-4 py-2">Disable</th>
                    </tr>
                  </thead>
                  <tbody>
                    {users.map((u) => (
                      <tr key={u._id} className="border-b hover:bg-gray-50">
                        <td className="px-4 py-2">
                          <img src={u.avatar} alt={u.username} className="w-8 h-8 rounded-full object-cover" />
                        </td>
                        <td className="px-4 py-2 font-medium">{u.username}</td>
                        <td className="px-4 py-2">{u.fullname}</td>
                        <td className="px-4 py-2">{u.email}</td>
                        <td className="px-4 py-2">{u.phone}</td>
                        <td className="px-4 py-2">{u.gender}</td>
                        <td className="px-4 py-2">{u.birthday ? new Date(u.birthday).toLocaleDateString() : ""}</td>
                        <td className="px-4 py-2">
                            <Badge variant={u.isDisable ? "destructive" : "success"}>
                              {u.isDisable ? "Disabled" : "Active"}
                            </Badge>
                          </td>
                      </tr>
                    ))}
                  </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
